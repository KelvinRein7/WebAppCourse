Commentes are before amlost every functions and they show what the function does.

For designs, I went to try "Courier new", Courier, monospace font as
it is pretty standard font for programmers.

Add little background color to the select dropdown box.
