
let vendor01 = {
	name: "Staples",
	min_order: 20,
	delivery_fee: 5,
	supplies: {
		"Paper": {
			0: {
				name: "Printer Paper",
				description: "odio semper cursus. Integer mollis.",
				stock: 3,
				price: 5.50
			},
			1: {
				name: "Copy Paper",
				description: "elit pede, malesuada vel, venenatis.",
				stock: 6,
				price: 6.00
			},
			2: { 
				name: "Specialty Paper",
				description: "tellus sem mollis dui, in",
				stock: 15,
				price: 11.50
			},
			3: {
				name: "Notebook",
				description: "sit amet nulla. Donec non",
				stock: 45,
				price: 3.99
			},
			4: {
				name: "Cardstock",
				description: "Lorem ipsum dolor sit amet,",
				stock: 45,
				price: 10.50
			},
			5: {
				name: "Calendar",
				description: "Aliquam tincidunt, nunc ac mattis",
				stock: 6,
				price: 7.00
			}
		},
		"Writing Supplies": {
			6: {
				name: "Pen",
				description: "tellus. Aenean egestas hendrerit neque",
				stock: 60,
				price: 4.99
			},
			7: {
				name: "Mechanical Pencil Lead",
				description: "magna, malesuada vel, convallis in,",
				stock: 8,
				price: 4.00
			},
			8: {
				name: "Pencils (pack of 10)",
				description: "nec quam. Curabitur vel lectus.",
				stock: 33,
				price: 9.75
			},
			9: {
				name: "Markers",
				description: "Aliquam tincidunt, nunc ac mattis",
				stock: 4,
				price: 13.33

			},
			10: {
				name: "Eraser",
				description: "odio. Etiam ligula tortor, dictum",
				stock: 17,
				price: 1.50
			},
			11: {
				name: "Pencil Sharpener",
				description: "tincidunt, nunc ac mattis ornare,",
				stock: 2,
				price: 3.99
			},
			12: {
				name: "Fine Writing Pen Case",
				description: "Sed pharetra, felis eget varius",
				stock: 6,
				price: 15.99
			}
		},
		"Accessories": {
			13: {
				name: "Scissors",
				description: "Nam tempor diam dictum sapien.",
				stock: 10,
				price: 9.99
			},
			14: {
				name: "Glue Sticks (pack of 3)",
				description: "ipsum primis in faucibus orci",
				stock: 19,
				price: 4.99
			},
			15: {
				name: "3-Digit Combination Lock",
				description: "aliquet. Proin velit. Sed malesuada",
				stock: 4,
				price: 11.99
			}
		}
	}
}

let vendor02 = {
	name: "Indigo",
	min_order: 15,
	delivery_fee: 3.99,
	supplies: {
		"Creativity": {
			0: {
				name: "ABT MARKERS, PINK 5PK",
				description: "Sed auctor odio a purus.",
				stock: 30,
				price: 10.50
			},
			1: {
				name: "SET 0F 12 DUSTLESS CHALK",
				description: "quis arcu vel quam dignissim",
				stock: 10,
				price: 12.55
			},
			2: {
				name: "SET OF 12 DUAL ENDED COLOURING PENCILS",
				description: "diam luctus lobortis. Class aptent",
				stock: 11,
				price: 12.99
			}
		},
		"Journals": {
			3: {
				name: "SET OF 3 SPIRAL NOTEBOOKS, LAVENDER",
				description: "eget, volutpat ornare, facilisis eget",
				stock: 8,
				price: 15.00
			},
			4: {
				name: "COPTIC TAB NOTEBOOK, PINK",
				description: "euismod enim. Etiam gravida molestie",
				stock: 9,
				price: 11.00
			},
			5: {
				name: "A5 3-SUBJECT SPIRAL NOTEBOOK, ABSTRACT",
				description: "Donec vitae erat vel pede",
				stock: 14,
				price: 12.99
			}
		}
	}
}

let vendor03 = {
	name: "Grand and Toy",
	min_order: 35,
	delivery_fee: 8,
	supplies: {
		"Whiteboards": {
			0: {
				name: "Cork Board",
				description: "Nunc sed orci lobortis augue",
				stock: 7,
				price: 19.00
			},
			1: {
				name: "Glass Dry-Erase Board",
				description: "nisl. Quisque fringilla euismod enim.",
				stock: 2,
				price: 149.00
			},
			2: {
				name: "Planning Board",
				description: "arcu. Sed et libero. Proin",
				stock: 19,
				price: 11.99
			}

		},
		"Organizers": {
			3: {
				name: "Desk Pad",
				description: "euismod enim. Etiam gravida molestie",
				stock: 4,
				price: 4.50
			},
			4: {
				name: "Document Holder",
				description: "lobortis quis, pede. Suspendisse dui",
				stock: 19,
				price: 5.99
			},
			5: {
				name: "Cubicle Hook",
				description: "lobortis quam a felis ullamcorper",
				stock: 11,
				price: 1.99
			}
		},
		"Paper": {
			6: {
				name: "Coloured Printer Paper",
				description: "sed pede. Cum sociis natoque",
				stock: 6,
				price: 7.00
			},
			7: {
				name: "Photo Paper",
				description: "Nunc laoreet lectus quis massa.",
				stock: 19,
				price: 17.70
			},
			8: {
				name: "Thermal Roll",
				description: "Donec egestas. Duis ac arcu.",
				stock: 4,
				price: 6.99
			}
		},
		"Craft Supplies": {
			9: {
				name: "Stickers (pack of 100)",
				description: "luctus ut, pellentesque eget, dictum",
				stock: 60,
				price: 3.99
			},
			10: {
				name: "Pom Poms (pack of 300)",
				description: "Nam ac nulla. In tincidunt",
				stock: 3,
				price: 8.00
			},
			11: {
				name: "Glitter Glue (300ml)",
				description: "interdum enim non nisi. Aenean",
				stock: 40,
				price: 5.99
			}
		},
		"Writing Supplies": {
			12: {
				name: "Highlighters (pack of 5)",
				description: "Phasellus dolor elit, pellentesque a,",
				stock: 19,
				price: 7.95
			},
			13: {
				name: "Blue Ink Pens (pack of 10)",
				description: "fames ac turpis egestas. Aliquam",
				stock: 3,
				price: 11.50
			},
			14: {
				name: "Sharpie Markers (pack of 3)",
				description: "aliquet odio. Etiam ligula tortor,",
				stock: 5,
				price: 5.99
			},
			15: {
				name: "Pen Refills (pack of 20)",
				description: "semper, dui lectus rutrum urna,",
				stock: 67,
				price: 10.58
			}
		},
		"Storage": {
			16: {
				name: "Storage Box",
				description: "at auctor ullamcorper, nisl arcu",
				stock: 9,
				price: 5.78
			},
			17: {
				name: "Binding Cases (pack of 10)",
				description: "penatibus et magnis dis parturient",
				stock: 39,
				price: 7.99
			},
			18: {
				name: "File Storage Drawer",
				description: "Pellentesque ut ipsum ac mi",
				stock: 2,
				price: 46.50
			},
			19: {
				name: "Portable Plastic File/Storage Box",
				description: "rhoncus. Proin nisl sem, consequat",
				stock: 5,
				price: 16.79
			}
		},
		"Security": {
			20: {
				name: "Key Cabinet",
				description: "mus. Donec dignissim magna a",
				stock: 1,
				price: 115.00
			},
			21: {
				name: "Key Safe",
				description: "cursus. Integer mollis. Integer tincidunt",
				stock: 5,
				price: 57.99
			}
		}
	}
}

let vendors = { "Staples": vendor01, "Indigo": vendor02, "Grand and Toy": vendor03 };
let vendorsArr = [vendor01, vendor02, vendor03];
let order = [];

let select = document.getElementById("vendor-select");
let currentVendor = select.selectedIndex;


function init() {
	
	document.getElementById("vendor-select").innerHTML = genSelList();

}

function genSelList() {
	let result = '<select name="vendor-select" id="vendor-select">';
	result += `<option value="Select Restaurant">Select Restaurant</option>`
	Object.keys(vendors).forEach(elem => {
		result += `<option value="${elem}">${elem}</option>`
		// console.log(vendors["Grand and Toy"].delivery_fee)
	});
	result += "</select>";
	return result;
}

//this is the middle column which is where all the items will be listed and the user will be able to add itesms to their cart here
function vendorItems(vendorName) {

	let leftSec = document.getElementById("left");
	leftSec.class = "columnleft";
	leftSec.innerHTML = "";

	let midSec = document.getElementById("middle");
	//midSec.class = "columnmiddle";
	midSec.innerHTML = "";

	//main
	let mainClass = document.createElement("div");
	mainClass.class = "main";

	let venName = document.createElement("h1");
	venName.innerHTML = vendorName.name;
	mainClass.appendChild(venName);

	let min_order = document.createElement("p");
	min_order.id = "minOrder";
	min_order.value = vendorName.min_order;
	min_order.innerHTML = "Minimum Order Price: $" + vendorName.min_order.toFixed(2);
	mainClass.appendChild(min_order);

	let delivery_fee = document.createElement("p");
	delivery_fee.id = "delivery_fee";
	delivery_fee.innerHTML = "Delivery Fee: $" + vendorName.delivery_fee.toFixed(2);
	mainClass.appendChild(delivery_fee);

	let categories = document.createElement("h2");
	categories.id = "categories";
	categories.innerHTML = "Categories";
	mainClass.appendChild(categories);

	//section list using ul and li
	let secList = document.createElement("ul");

	Object.keys(vendorName.supplies).forEach(ele => {
		let itemsList = document.createElement("li");
		let toLink = document.createElement("a");

		//scrolled down to whatever the category the user click                   
		toLink.class = "toLink";
		toLink.href = "#" + ele;
		toLink.innerHTML = ele;

		itemsList.appendChild(toLink);
		secList.appendChild(itemsList);
		leftSec.appendChild(secList);
		});
	mainClass.appendChild(leftSec);
	//end of left column

	//middle column starts here

	//vendor supply-categories name
	//	vendor supply-items name
	//	vendor items desciption
	//	vendor items prices and stocks

	for(let ele in vendorName.supplies) {

		let itemList = document.createElement("div");

		itemList.id = ele;

		itemList.class = "columnmiddle";

		let itemsName = document.createElement("h3");

		itemsName.innerHTML = ele;

		itemList.appendChild(itemsName);

		Object.values(vendorName.supplies[ele]).forEach(items => {
			
			let itemDiv = document.createElement("div");
			let itemInfo = document.createElement("p");
			let buttonImg = document.createElement("img");

			//lastedit
			let name = document.createElement("h3");
			let description = document.createElement("p");
			let price = document.createElement("p");
			itemDiv.id = items.name;
			itemInfo.innerHTML = items.name;
			itemDiv.innerHTML = items.name;
			description.innerHTML = items.description;
			price.innerHTML = "($ "+ items.price.toFixed(2) + ") " + 
			"Stock=" +items.stock;

			buttonImg.src = "add.png";
			buttonImg.style.float = "middle";
			buttonImg.width = 17;
			buttonImg.alt = items.name;
			buttonImg.addEventListener("click", addItem);

			// itemDiv.id = items.name;
			// itemInfo.innerHTML = items.name + ` ($${items.price}, Stock=${items.stock})` + "<br>"+ items.description;

			name.appendChild(itemDiv)
			itemDiv.appendChild(buttonImg);
			itemDiv.appendChild(price);
			itemDiv.appendChild(description);
			itemList.appendChild(itemDiv);

		});
		midSec.appendChild(itemList);
}
	mainClass.appendChild(midSec);

	mainClass.appendChild(orderSummary(vendorName));

	return mainClass;
}


//this fucntion shows  the order summary on the left side of the screen
//with all required info
function orderSummary(vendorName){

	let rightSec = document.createElement("div");
	rightSec.id="right";
	rightSec.class = "columnright";
	let deliveryCharge = vendorName.delivery_fee;
	let subTotal = 0;
	rightSec.innerHTML = "";

	order.forEach(x =>{
		let item = document.createElement("div");
		let name = document.createElement("h3");
		let price = document.createElement("p");
		let quantity = document.createElement("p");
		let remove = document.createElement("img");

		quantity.innerHTML = x.name + " x " + x.quantity + " (" + (x.price * x.quantity).toFixed(2) + ")";


		remove.addEventListener("click", removeItem);

		remove.src = "remove.png";
		remove.class = "removeButton";
		remove.width = 17;
		remove.alt = x.name;

		quantity.appendChild(remove);
		item.appendChild(name);
		item.appendChild(quantity);
		item.appendChild(price);


		rightSec.appendChild(item);

		subTotal = subTotal + x.price * x.quantity;
	});

	//-------display order summary section

	//sub total
	let sub = document.createElement("h3");
	sub.id= "subtotal";
	sub.value = subTotal;
	sub.innerHTML = "Subtotal: $" + subTotal.toFixed(2);
	rightSec.appendChild(sub);

	//tax amount
	let tax = document.createElement("h3");
	let taxPercentage = (subTotal + deliveryCharge) * 0.1;
	tax.innerHTML= "Tax: $" + taxPercentage.toFixed(2);
	rightSec.appendChild(tax);

	let delivery = document.createElement("h3");
	delivery.innerHTML = "Delivery Fee: $" + deliveryCharge.toFixed(2);
	rightSec.appendChild(delivery);

	let total = document.createElement("h3");
	let totalCalc = subTotal + deliveryCharge + taxPercentage;
	total.innerHTML = "Total: $" + totalCalc.toFixed(2);
	rightSec.appendChild(total);

	let submitOrder= document.createElement("button");
	submitOrder.onclick = submitItem;
	submitOrder.innerHTML = "Submit Order";
	rightSec.appendChild(submitOrder);

	let warning = document.createElement("p");
	warning.id = "warning";
	rightSec.appendChild(warning);


return(rightSec);


}


//will ask user whether the user want to change vendor or not
//if so/ everything will be reset
function changeVendor() {
		
	if(order.length > 0 ) {

		if (confirm("Are you sure you want to change vendor? Items in you cart will be lost!")) {

			order = [];

			if(!select.value){
			 	select.value = vendor01;
				
			};
			printVendor();
		}
	}
	else {
	
		printVendor();
	}
}

//helper function to reduce repetitive codes
function printVendor() {
	let mainClass = document.getElementById("main");

	vendorsArr.forEach((option) => {
		if (option.name === select.value) {
			let newMenu = vendorItems(option);
			mainClass.innerHTML = "";
			mainClass.appendChild(newMenu);
		}
	});
	
}

//this funciton will add any item that the user chose to add to the cart and 
function addItem(){
	let itemName = this.getAttribute('alt');

	let newItem = document.getElementById(itemName);

	//access childnode since the nodes are append in order
	//split the space to get the number as a whole
	let price = newItem.childNodes[2].innerHTML.split(" ")[1];

	//to get the total stocks
	let instockItem = newItem.childNodes[2].innerHTML.split(" ")[2];

	instock = false;

	//for loop prints out a new line of order         
	order.forEach(item => {
		if (item.name === itemName) {
			item.quantity = item.quantity + 1;

			instock = true;
			}
	});

	if(!instock)
		order.push({name: itemName, price: parseFloat(price), quantity: 1});

	printVendor();

}

//this function will remove the order that the user dont want to buy anymore or reduce quantity due to limited stock
function removeItem() {
	let itemName = this.getAttribute('alt');
	for(let item in order) {
		if (item.name === itemName) {
			item.quantity = item.quantity  - 1;
			if(item.quantity <= 0 ){
				order.splice(order.indexOf(item), 1);
			}
		}
	}

	printVendor();

}

//this function will confirm whether the order is submitted successfully
//if order amount does not meet minumum amount -> it will warn the user to order more
function submitItem() {
	let subtotal = document.getElementById("subtotal").value;
	let minOrder = document.getElementById("minOrder").value;
	let warning = document.getElementById("warning");

	if(subtotal > minOrder ){
		alert("Ordered Successfully!");
		order = [];
		changeVendor();
	}
	else {
		warning.innerHTML = "Your need to order at least $" + minOrder + ". You need $" + (minOrder - subtotal).toFixed(2) + " more.";
	}

}
