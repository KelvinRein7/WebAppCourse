
function init() {

  var totalButtonsAndStars = 13;
  
  for (let i = 1; i< totalButtonsAndStars; i++){

    const button = document.createElement('button')

    button.innerText = `Rate ${i}`;
  
    button.addEventListener('click', () => {})

    let click = document.getElementById("buttons").appendChild(button)

    click.onclick = () => {updateRating(i)}

  }

  for (let i = 1; i < totalButtonsAndStars; i++ ){

      result = `<span id="rating${i}">&#9733;</span> `;

      document.getElementById("stars").innerHTML += result;
  }
}