// var test = function (input) {
//   const foo = "hello";
//   const bar = "world";

//   setTimeout(function () {
//     console.log(bar);
//   }, 10000);
//   console.log(foo);
// };

// test();

// var test2 = function (input) {
//   let foo = 0;

//   if (foo && foo == false) {
//     console.log("1");
//     foo = [];
//   } else if (foo == undefined || !foo) {
//     console.log("2");
//     foo = "";
//   }

//   if (foo === null) {
//     console.log("3");
//   } else if (foo == NaN) {
//     console.log("4");
//   } else {
//     console.log("5");
//   }
// };

// test2();

// function mN(x, y) {
//   var ans = x * y;
//   return ans;
// }

// var z = mN(2, 3);
// console.log(ans);

// test3();

// let f = "pizza";
// console.log("My favourite food is " + f + ".");
