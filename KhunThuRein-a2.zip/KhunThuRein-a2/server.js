// add your server code here
const http = require('http');
const fs = require('fs');

//pug template engine
const pug = require('pug');

//set vendor data
let vendorJSON = fs.readdirSync('./vendors');

//take each vendor then store on the server and store the info
let vendorData = {};

//store stats for the vendors
let vendorStats = {};

//for each of the vendor, we will take the data and store them on the local server side
vendorJSON.forEach(name => {
  let vendorName = name.replace(".json", "");
  vendorData[vendorName] = require("./vendors/" + name);
});

//data for stats table is initialized here
for(let vendor in vendorData){
  vendorStats[vendorData[vendor].name] = vendorData[vendor];
  vendorStats[vendorData[vendor].name].totalOrder = 0;
  vendorStats[vendorData[vendor].name].totalAvg = "0.0";
  vendorStats[vendorData[vendor].name].popularItem = "Unavailable";
}


//creating server with request and response
const server = http.createServer(function (request, response){
  //if GET request is asked, load homepage.html
  if(request.method === 'GET'){
    if(request.url === '/' || request.url === '/homepage.html'){
      fs.readFile("homepage.html", function(err, data){

        //check if there is any error, if so, show error message else the page will load
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "text/html");
        response.write(data);
        response.end();
      });
    }

    //style sheet for homepage
    else if(request.url === '/homepage.css'){
      fs.readFile('homepage.css', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "text/css");
        response.write(data);
        response.end();
      });
    }

    //background image from local storage will be used for the server side
    else if(request.url === '/background.jpg'){
      fs.readFile('background.jpg', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "image/jpg");
        response.write(data);
        response.end();
      });
    }

    //orderform html page load
    else if(request.url === '/orderform'){
      fs.readFile('orderform.html', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "text/html");
        response.write(data);
        response.end();
      });
    }

    //style sheet for orderform page
    else if(request.url === '/orderform.css'){
      fs.readFile('orderform.css', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "text/css");
        response.write(data);
        response.end();
      });
    }

    //call client js file for server side
    else if(request.url === '/client.js'){
      fs.readFile('client.js', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "application/javascript");
        response.write(data);
        response.end();
      });
    }

    //add button
    else if(request.url === '/add.png'){
      fs.readFile('add.png', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "image/png");
        response.write(data);
        response.end();
      });
    }

    //remove button
    else if(request.url === '/remove.png'){
      fs.readFile('remove.png', function(err, data){
        if(err){
          response.statusCode = 500;
          response.write("Internal Server Error.")
          response.end();
          return;
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "image/png");
        response.write(data);
        response.end();
      });
    }

    //we want to send all the data related to the vendors to the page were customers can see
    else if(request.url === '/vendors'){
      response.statusCode = 200;
      response.setHeader("Content-Type", "application/JSON");
      response.write(JSON.stringify(vendorData));
      response.end();
    }

    //after sending, each vendor's data will be sent to the page for the customers
    else if(request.url.startsWith('/vendors/')){
      let vendor = request.url.slice(9);
      response.statusCode = 200;
      response.setHeader("Content-Type", "application/JSON");
      response.write(JSON.stringify(vendorData[vendor]));
      response.end();
    }

    //this is where the data related to the vendor's stats will be send
    else if(request.url.startsWith('/stats')){
      //pug template engine
      //each vendor's stats will be sent to the stats.pug to display
      let data = pug.renderFile("stats.pug",  {vendorStats: vendorStats});
      response.statusCode = 200;
      response.end(data);
      return;
    }
    else{
      errorStatus(response);
      return;
    }
  }

  //wait for the customers to send the data (Which is Submitting the order in the case) by sending a PUT request
  else if(request.method === 'PUT'){
    if(request.url === '/submit'){
      let data = '';
      let userInput;
      request.on('data', (chunk) => {
        data = chunk;
      });

      //after the user submitted, the updated data will be sent over to where we store the vendor's stats (vendorStats)
      request.on("end", () => {
        userInput = JSON.parse(data);

        //if there is a second successful order for the current vendor
        if(vendorStats[userInput.name].totalOrder >= 1){
          //increment the total order by 1
          vendorStats[userInput.name].totalOrder++;

          //re-calculate the total average amount
          vendorStats[userInput.name].totalAvg = (userInput.totalAvg/vendorStats[userInput.name].totalOrder + vendorStats[userInput.name].totalAvg * (1/(vendorStats[userInput.name].totalOrder/(vendorStats[userInput.name].totalOrder - 1)))).toFixed(2);

          //
          for(let category in vendorStats[userInput.name].supplies){
            for(let item in vendorStats[userInput.name].supplies[category]){
              //check if the customer order the item successully
              //if unsuccessful, the number of item customer bought is 0
              if(typeof(vendorStats[userInput.name].supplies[category][item].buyCount) == 'undefined'){
                vendorStats[userInput.name].supplies[category][item].buyCount = 0;
              }
              //if successful, the number of item customer bought is increased by the count he/she bought
              if(typeof(userInput.supplies[category][item].buyCount) != 'undefined'){
                vendorStats[userInput.name].supplies[category][item].buyCount += userInput.supplies[category][item].buyCount;
              }
            }
          }
        }
        else{
          //if this is the first order of the current vendor

          //the data will be set for the current vendor as it is shown on the order summary (For example: totalavg = subtotal)
          vendorStats[userInput.name] = userInput;
          //total average with two decimal places
          vendorStats[userInput.name].totalAvg = vendorStats[userInput.name].totalAvg.toFixed(2);
          //first order so total order will be 1
          vendorStats[userInput.name].totalOrder = 1;
        }

        //
        for(let vendor in vendorStats){
          let trackPopular = 0;
          //since we specifically want the name of the item from the supplies (shown as Categories on the page)

          //we will track each supply for each item
          if(vendorStats[vendor].hasOwnProperty("supplies")){

            //for each category of the supplies
            for(let category in vendorStats[vendor].supplies){

              //for each item that is included in each category of the supplies
              for(let item in vendorStats[vendor].supplies[category]){

                //most popular item is determined by the number of sales for that item

                //check if latest bought item count is GREATER than or EQUAL to the previous most popular item
                if(vendorStats[vendor].supplies[category][item].buyCount >= trackPopular){

                  //replace NEW most popular item to the previous one (trackPopular)
                  trackPopular = vendorStats[vendor].supplies[category][item].buyCount;
                  vendorStats[vendor].popularItem = vendorStats[vendor].supplies[category][item].name;
                }
              }
            }
          }
        }
        response.statusCode = 200;
        response.setHeader("Content-Type", "text/plain");
        response.write("Server is up to date.");
        response.end();
      });
    }
    else{
      errorStatus(response);
      return;
    }
  }
  else{
    errorStatus(response);
    return;
  } 
});


//server starts here
server.listen(3000);
console.log("Server listening at http://localhost:3000");

//for 404 response if the server failed
function errorStatus(response){
  response.statusCode = 404;
  response.write("Couldn't reach the page");
  response.end();
  return;
}