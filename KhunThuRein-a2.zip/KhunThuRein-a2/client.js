//The drop-down menu

let select = document.getElementById("vendor-select");


//Stores the currently selected vendor index to allow it to be set back when switching vendors is cancelled by user
let currentSelectIndex = select.selectedIndex;


//Stores the current vendor to easily retrieve data. The assumption is that this object is following the same format as the data included above. If you retrieve the vendor data from the server and assign it to this variable, the client order form code should work automatically.
let currentVendor;
//Stored the order data. Will have a key with each item ID that is in the order, with the associated value being the number of that item in the order.
let order = {};

//Called on page load. Initialize the drop-down list, add event handlers, and default to the first vendor.
function init() {

	//http request to get vendor info from server
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		//check the state of the server
		if(this.readyState == 4 && this.status == 200) {
			let vendors = JSON.parse(xhttp.responseText);

			//this will change vendor when one of the options from the drop down list is selected
			select.addEventListener("change", selectVendor);

			for(let name in vendors){
				let vendorOption = document.createElement("option");
				vendorOption.setAttribute("value",name);
				vendorOption.innerHTML = vendors[name].name;
				select.appendChild(vendorOption);
				console.log(vendors[name].name);
			}
			console.log(vendors);
			order.option = select.selectedIndex;
			//current vendor's name
			order.currentVendor = vendors[select.value];
			//declare subtotal
			order.subTotal = 0;
			//declare total item added
			order.totalItem = 0;
			display();
		}
	};
	xhttp.open("GET", "http://localhost:3000/vendors", true);
	xhttp.send();
}

function display(){
		
//left section of the page
let leftSec = document.getElementById("left");
leftSec.class = "columnleft";
leftSec.innerHTML = "";

//mid section of the page
let midSec = document.getElementById("middle");
midSec.class = "columnmiddle";
midSec.innerHTML = "";

//display current vendor's name
let venName = document.createElement("h1");
venName.innerHTML = order.currentVendor.name;
leftSec.appendChild(venName);

//display minimum order amount
let min_order = document.createElement("p");
min_order.id = "minOrder";
min_order.value = order.currentVendor.min_order;
min_order.innerHTML = "Minimum Order Price: $" + order.currentVendor.min_order.toFixed(2);
leftSec.appendChild(min_order);

//display delivery fee amount
let delivery_fee = document.createElement("p");
delivery_fee.id = "delivery_fee";
delivery_fee.innerHTML = "Delivery Fee: $" + order.currentVendor.delivery_fee.toFixed(2);
leftSec.appendChild(delivery_fee);

//categories header
let categories = document.createElement("h2");
categories.id = "left-categories";
categories.innerHTML = "Categories";
leftSec.appendChild(categories);

//section list using ul and li 
let secList = document.createElement("ul");

//iterate throught each vendor's supplies and create anchor tag
Object.keys(order.currentVendor.supplies).forEach(ele => {
	let itemsList = document.createElement("li");
	let toLink = document.createElement("a");

	//scrolled down to whatever the category the user click
	//create anchor link
	toLink.class = "toLink";
	toLink.href = "#" + ele;
	toLink.innerHTML = ele;

	itemsList.appendChild(toLink);
	secList.appendChild(itemsList);
	leftSec.appendChild(secList);
	});

//Adding new item to the category
let addNew =  document.createElement("h2");
addNew.innerHTML = "Add New Item to Category:";
leftSec.appendChild(addNew);

	dispalyItems();
	displayOrder();

}

//this function display the items from each category of the supplies
function dispalyItems(){
	
	//list of item parent node
	let itemList = document.getElementById("middle");
	itemList.innerHTML="";

	//loop for each category in vendors object
	for(let [categoryName, item] of Object.entries(order.currentVendor.supplies)){ 

			let category = document.createElement("h2");
			category.setAttribute("id", "middle");
			category.setAttribute("class","mid-categories");
			category.innerHTML = categoryName;
			itemList.appendChild(category);

			//loop for every single item of each category
			for(let itemId in item){
					let itemHeader = document.createElement("p");
					itemHeader.setAttribute("id",item[itemId].name);
					itemHeader.setAttribute("class","item-names");
					
					//item description
					let itemInfo = document.createElement("p");
					itemInfo.setAttribute("class", "item-info");
					itemInfo.innerHTML=item[itemId].description;

					//add button
					let addItem = document.createElement("input");
					addItem.setAttribute("type","image");
					addItem.setAttribute("src","add.png");
					addItem.setAttribute("class","add-image");

					itemList.appendChild(itemHeader);

					//item price
					let priceText = document.createElement("p");
					priceText.setAttribute("class","mid-price");

					//item name, item price and item stock in the same line
					itemHeader.innerHTML=item[itemId].name + ` ($${item[itemId].price}, Stock=${item[itemId].stock})`;

					//the functionality when the user click the add button (on click)
					addItem.addEventListener("click", () =>{
						if (item[itemId].buyCount == item[itemId].stock){
								alert("Out of stock!")
							}
							//increment the number of items added to the cart by 1 everytime the user click the button
							else if(typeof item[itemId].buyCount != "undefined"){
									item[itemId].buyCount += 1;
									order.totalItem++;
							}
							else{
									item[itemId].buyCount = 1;
									order.totalItem++;
							}
							//the page has to render everytime the user do any update
							display();
					});
					itemHeader.appendChild(addItem);
					itemHeader.appendChild(itemInfo);
					itemHeader.appendChild(document.createElement("br"));
			}
	}

}

//this function display the order summary when the user add or remove items
function displayOrder() {

	//subtotal from order object
	order.subTotal = 0;

	//right column of the page
	let orderSummary = document.getElementById("right");
	orderSummary.innerHTML = "";

	//right section of the page
	let currentOrder = document.createElement("h2");
	currentOrder.setAttribute("class", "columnright");
	orderSummary.appendChild(currentOrder);

	//here we create the text to display
	for(let [categoryName, item] of Object.entries(order.currentVendor.supplies)) {
		for(let itemId in item){
			if(typeof item[itemId].buyCount != "undefined" && item[itemId].buyCount > 0){

				let orderList = document.createElement("p");
				orderList.setAttribute("class", "order-list");
				//display item name, the number of items user want to buy, and item amount x item cost = price
				orderList.innerHTML = item[itemId].name + " x " + item[itemId].buyCount + " ($"+(item[itemId].buyCount * item[itemId].price).toFixed(2) + ")";

				orderSummary.appendChild(orderList);

				//add to subtotal amount
				order.subTotal = order.subTotal + (item[itemId].buyCount * item[itemId].price);

				//remove button
				let removeItem = document.createElement("input");
          removeItem.setAttribute("type","image");
          removeItem.setAttribute("src","remove.png");
	        removeItem.setAttribute("class","remove-image");
					//functionality for remove button
        	removeItem.addEventListener("click", () =>{
						//decrement by 1 from the amount the user added for each click
            item[itemId].buyCount--;
						
						//decrement by 1 from totalItem as we TRACK the items in the cart
						//if there were items before BUT user already removed them, then changing vendor MUST NOT give any alert
            order.totalItem--;
						//console.log(order.totalItem--);
            display();
         });
				 orderList.appendChild(removeItem);
				 orderSummary.appendChild(document.createElement("br"));
			}
		}
	}

	//displaying subtotal
	let subTotal = document.createElement("p");
	subTotal.setAttribute("class", "price-right");
	subTotal.innerHTML = "Subtotal: $" + order.subTotal.toFixed(2);
	orderSummary.appendChild(subTotal);
	
	//displaying tax
	let tax = document.createElement("p");
	tax.setAttribute("class", "price-right");
	tax.innerHTML = "Tax: $" + (order.subTotal * 0.1).toFixed(2);
	orderSummary.appendChild(tax);

	//displaying delivery fee
	let deliFee = document.createElement("p");
	deliFee.setAttribute("class", "price-right");
	deliFee.innerHTML = "Delivery Fee: $" + order.currentVendor.delivery_fee.toFixed(2);
	orderSummary.appendChild(deliFee);

	//display total order cost
	let total = document.createElement("p");
	total.setAttribute("class", "price-right");
	total.innerHTML = "Total: $" + (order.subTotal+(order.subTotal*0.1)+order.currentVendor.delivery_fee).toFixed(2);
	orderSummary.appendChild(total);


	//track total average from each order added
	//display the avg amount in stats table
	//avg of first order for whatever vendor it is
	order.currentVendor.totalAvg = order.subTotal + (order.subTotal * 0.1) + order.currentVendor.delivery_fee;

	//check if subTotal is BIGGER than the current vendor's minimum required amount
	if(order.subTotal >= order.currentVendor.min_order){
		let submitOrder = document.createElement("input");
		submitOrder.setAttribute("class", "submit-order")
		submitOrder.setAttribute("type", "button");
		submitOrder.setAttribute("value", "Submit Order");
		submitOrder.addEventListener("click", ()=> {

			let xhttp = new XMLHttpRequest();

			xhttp.onreadystatechange = function() {
				if(this.readyState == 4 && this.status == 200){
					alert("Order submitted successfully!");
					//reset after each order the user submitted
					resetData();
				}
			};

			xhttp.open("PUT","http://localhost:3000/submit"); // PUT request to send userData to the server for it to be processed
            xhttp.setRequestHeader("Content-Type","application/JSON");
            let data = JSON.stringify(order.currentVendor);
            xhttp.send(data);
		});
		orderSummary.appendChild(document.createElement("br"));
		orderSummary.appendChild(submitOrder);
	}
	else{ // If the subtotal<delivery-fee then append a <p> tag that contains the amount that still needs to be paid
		notEnough = document.createElement("p");
		notEnough.setAttribute("class","price-right");
		notEnough.innerHTML="You must add $"+(order.currentVendor.min_order - order.subTotal).toFixed(2)+" to your order before submitting.";
		orderSummary.appendChild(notEnough);
}
}

//This function will reset the data in the cart, the totalItem that we tracked, the number of items we bought
//after each order is submitted successfully
function resetData() {

	for(let[categoryName, item] of Object.entries(order.currentVendor.supplies)) {
		for(let itemId in item){
			item[itemId].buyCount = 0;
		}
	}
order.totalItem = 0;
display();
}

//Called when drop-down list item is changed.
//For A2, you will likely have to make an XMLHttpRequest here to retrieve the supplies list data for the selected vendor
function selectVendor() {

	//is there is no item in the order summary, we can let the user change vendor without any alert message
	if(order.totalItem==0){
			changeVendor();
	}
	else{
			userChoice = confirm("Would you like to clear the current order?");
			//if the user cancle (doesnt want to change vendor), the vendor in dropdown wont change
			if(userChoice === false){
					select.selectedIndex = order.option;
			}
			else{
				//if user wants to change, everything will be reset and the page has turned into another vendor's page
					resetData();
					changeVendor();
			}
	}
}

//this function will let us store the selected vendor's data and will give us the data required depending on the selected vendor
function changeVendor(){
	let vendorselect = document.getElementById("vendor-select")
	order.option = vendorselect.selectedIndex;
	//request to get data from another vendor
	let xhttp = new XMLHttpRequest(); 

xhttp.onreadystatechange = function() {
	if (this.readyState == 4 && this.status == 200) {
		//the current selected vendor's data are stored
		order.currentVendor = JSON.parse(xhttp.responseText);
		display();
	}
};

//send GET request and we will get the data we want
xhttp.open("GET", "http://localhost:3000/vendors/" + vendorselect.value, true);
xhttp.send();
}

