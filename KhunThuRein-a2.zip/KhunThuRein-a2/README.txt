Steps to run the program

1. Unzip the assignment 2 folder

For VScode,
    1. Open the folder (file -> Open folder)
    2. Open Terminal -> New Terminal or Ctrl+Shift+` (for Window)
    3. Type npm install pug
    Then
    4. node server.js (server runs)

For the Terminal or Windows Powershell,
    1. Please make sure you are in the assignmen2 directory
    2. Type npm install pug
    3. node server.js (server runs)


2. Open your browser (Chrome, Firefox, etc.)
3. Type http://localhost:3000/
4. Home page of the website will be loaded

Further Documentation

1. Since we want to update the page everytime the user add or remove or buy or change vendor, PUT request is to be used rather than a POST request which will be doing the "creating" job which we do not necessarily need in this case. Hence, 200 as response code is used instead of 201.

2. GET request to retrieve data and PUT to update the data is enough in this case and this can be regarded as the RESTful implementation.