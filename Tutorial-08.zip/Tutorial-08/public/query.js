let refresh_button =document.getElementById("Refresh")

refresh_button.addEventListener('click', function(event){
     //document.getElementById("class").value
     //document.getElementById("rarity").value
    new XMLHttpRequest();
})