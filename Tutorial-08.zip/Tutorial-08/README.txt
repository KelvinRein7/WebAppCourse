Name: Khun Thu Rein
Student ID: 101186023

1. Open folder in VScode or Go to the folder's directory on terminal
2. npm install mongodb
3. npm install express
4. npm install pug
5. run database by typing 'node database-initializer.js'

This will show this message "xxxx cards are inserted successfully"

6. run server by typing 'node server.js'
