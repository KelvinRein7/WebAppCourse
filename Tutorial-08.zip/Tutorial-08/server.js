//Create express app
const express = require('express');
let app = express();

const path = require('path');
const bodyParser = require('body-parser');

//Database variables
app.use(express.static('public'));
app.use('/js', express.static(path.join(__dirname + '/public/js')));
app.use(express.json());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

let mongo = require('mongodb');
const exp = require('constants');
let MongoClient = mongo.MongoClient;
let db;

//View engine
app.set("view engine", "pug");

//Set up the routes
app.use(express.static("public"));
app.get("/", sendIndex);
app.get("/cards/:cardID", sendCard);

//asynchronous function to use await operator
//Problem 1
async function sendIndex(req, res, next){
	try{
		//give array of unique card classes within database
		const getClass  = await db.collection("cards").distinct("cardClass")
		console.log(getClass);

		//give array of rarity classes
		const getRarity = await db.collection("cards").distinct("rarity")
		console.log(getRarity);

		getRes = [];
		
		//render it to index.pug file to fill the dropdown
		res.render("index", {cla: getClass, rar: getRarity, cla_len: getClass.length, rar_len: getRarity.length, result_page: getRes});
	}
	catch(err){
		res.status(500).send(err);
	}
}

app.get("/card", sendMatchCard);

async function sendMatchCard(req, res, next){
	try{
		const getClass  = await db.collection("cards").distinct("cardClass");

		const getRarity = await db.collection("cards").distinct("rarity");

		//max health
		const maxH = req.query.maximum || 0;
		let temp;
		if(typeof maxH == "string"){
			temp = parseInt(maxH);
		}
		else{
			temp = maxH;
		}

		//min health
		const minH = req.query.minimum || 0;
		let temp1;
		if(typeof minH == "string"){
			temp1 = parseInt(minH);
		}
		else{
			temp1 = minH;
		}
		
		//max attack
		const maxAtt = req.query.maxatt || 0;
		let temp2;
		if(typeof maxAtt == "string"){
			temp2 = parseInt(maxAtt);
		}
		else{
			temp2 = maxAtt;
		}

		//min attack
		const minAtt = req.query.minatt || 0;
		let temp3;
		if(typeof minAtt == "string"){
			temp3 = parseInt(minAtt);
		}
		else{
			temp3 = minAtt;
		}

		for(i = 0; i < getClass.length; i++){
			if(getClass[i] == req.query.cla){
				//take element at position i of card class array and store it as temp4
				temp4 = getClass.splice(i, 1);
			}
		}

		for(i = 0; i < getRarity.length; i++){
			if(getRarity[i] == req.query.rae){
				//take element at position i of rarity class array and store it as temp5
				temp5 = getRarity.splice(i, 1);
			}
		}
	
		//add the sliced element to the very beginning of the get class and  get rarity array
		getClass.unshift(temp4[0]);
		getRarity.unshift(temp5[0]);

		let random_artist = "comp2406ghghghghgh";
	
		const temp_artist = req.query.art || random_artist;
	
		let random_name = "comp2406jkjkjkjkjk";
	
		const temp_name = req.query.nameC || random_name;

		if(temp_artist!= random_artist && temp_name!=random_name){
			const getRes=await db.collection("cards").find({$and:[{"rarity":req.query.rae,"cardClass":req.query.cla,"health":{$lte:temp},"health":{$gte:temp1},"attack":{$lte:temp2},"attack":{$gte:temp3},"artist":{$regex:temp_artist,$options:'i'},"name":{$regex:temp_name,$options:'i'}}]}).toArray()
			res.render("indexclient",{cla:getClass,rar:getRarity,cla_len:getClass.length,rar_len:getRarity.length, result_page:getRes})
		}
		else if(temp_name!=random_name){
			const getRes=await db.collection("cards").find({$and:[{"rarity":req.query.rae,"cardClass":req.query.cla,"health":{$lte:temp},"health":{$gte:temp1},"attack":{$lte:temp2},"attack":{$gte:temp3},"name":{$regex:temp_name,$options:'i'}}]}).toArray()
		//	console.log(getRes)
		res.render("indexclient",{cla:getClass,rar:getRarity,cla_len:getClass.length,rar_len:getRarity.length, result_page:getRes})
		}
		else if(temp_artist!=random_artist){
			const getRes=await db.collection("cards").find({$and:[{"rarity":req.query.rae,"cardClass":req.query.cla,"health":{$lte:temp},"health":{$gte:temp1},"attack":{$lte:temp2},"attack":{$gte:temp3},"artist":{$regex:temp_artist,$options:'i'}}]}).toArray()
			res.render("indexclient",{cla:getClass,rar:getRarity,cla_len:getClass.length,rar_len:getRarity.length, result_page:getRes})
		}
		else{
			const getRes=await db.collection("cards").find({$and:[{"rarity":req.query.rae,"cardClass":req.query.cla,"health":{$lte:temp},"health":{$gte:temp1},"attack":{$lte:temp2},"attack":{$gte:temp3}}]}).toArray()
			res.render("indexclient",{cla:getClass,rar:getRarity,cla_len:getClass.length,rar_len:getRarity.length, result_page:getRes})
		}	

	}
	catch(err){
		console.log("eww");
		res.status(500).send(err);
	}
}

function sendCard(req, res, next){
	let oid;
	try{
		oid = new mongo.ObjectId(req.params.cardID);
	}catch{
		res.status(404).send("Unknown ID");
		return;
	}

	db.collection("cards").findOne({"_id":oid}, function(err, result){
		if(err){
			res.status(500).send("Error reading database.");
			return;
		}
		if(!result){
			res.status(404).send("Unknown ID");
			return;
		}
		res.status(200).render("card", result);
	});
}

// Initialize database connection
MongoClient.connect("mongodb://127.0.0.1:27017/", { useNewUrlParser: true }, function(err, client) {
  if(err) throw err;

  //Get the t8 database
  db = client.db('t8');

  // Start server once Mongo is initialized
  app.listen(3000);
  console.log("Listening on port 3000");
});
