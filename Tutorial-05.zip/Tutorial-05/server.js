/*
Card source: https://api.hearthstonejson.com/v1/25770/enUS/cards.json

Each card is a JS object
All have:
	id - string uniquely identifies the card
	artist - string indicating the name of the artist for the cards image
	cardClass - string indicating the class of the card
	set  - string indicating the set the card is from
	type - string indicating the type of the card
	text - string indicating card text
Some have:
	rarity - string indicating the rarity of the card
	mechanics - array of string indicating special mechanics
	
Routes:
	/cards - search all cards (query params: class, set, type, artist)
	/cards/:cardID - specific card with ID=:cardID
*/

const http = require('http');
const pug = require('pug');

//Set up the required data
let cardData = require("./cards.json");

let cards = {}; //Stores all of the cards, key=id

let displayCard = {};

displayCard.displaySize=0;

cardData.forEach(card => {
	cards[card.id] = card;
	if(displayCard.displaySize <= 24){
		displayCard[card.id] = card;
		displayCard.displaySize++;
	}
});

// delete displayCard.displaySize;

//Initialize server
const server = http.createServer(function (request, response) {
	if(request.method === 'GET'){
		if(request.url === '/cards'){
			//pass the list of cards data here
			let data = pug.renderFile("cards.pug", {cards: displayCard});
			response.statusCode = 200;
			response.end(data);
			return;
		}
		else if(request.url.startsWith("/cards/")){
			//sliced first 7 values to reach to id value
			let id = request.url.slice(7);
			//look up the id for this object
			if(cards.hasOwnProperty(id)){
				//pass the card's id
				let data = pug.renderFile("card.pug", {card: cards[id]});
				response.statusCode = 200;
				response.end(data);
				return;
			}
			else{
				response.statusCode = 404;
				response.write("Unknown resource.");
				response.end();
				return;
			}
		}
		//problem 3 (query parameter)
		else if(request.url.startsWith("/cards?name=")){
			//sliced up to SET
			let name = decodeURIComponent(request.url.slice(12));
			console.log(name);

			let cardNameSearch = {};
			
			//for each card data in cardData object
			//populate the nwe cardNameSearch array if the name search is successful
			cardData.forEach(card => {
				//if searched name is in the list
				if(card.name.includes(name)){
					cardNameSearch[card.id] = card;
					console.log(card);
				}
			});

			//pass the name, page render
			let data = pug.renderFile("cards.pug", {cards: cardNameSearch});
			response.statusCode = 200;
			response.end(data);
			return;
		}
		else{
			response.statusCode = 404;
			response.write("Unknown resource.");
			response.end();
			return;
		}
	}
	else{
		response.statusCode = 404;
		response.write("Unknown resource.");
		response.end();
		return;
	}
});
//remove the size property are this is not needed to display
delete displayCard.displaySize;
//Start server
server.listen(3000);
console.log("Server listening at http://localhost:3000");
console.log("Run http://localhost:3000/cards to see the cards")