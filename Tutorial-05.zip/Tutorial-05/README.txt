cards.pug - this file is for displaying all the links to view the card 
card.pug - this file is for displaying each card if anchor link is clicked
cardCss.css - this file is for the style of displaying each card


On the terminal, in the directory where all the files are kept,

Step 1: npm install pug

Step 2: node server.js

Step 3: run http://localhost:3000/cards to see the cards