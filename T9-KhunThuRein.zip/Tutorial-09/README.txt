Name: Khun Thu Rein
ID: 101186023

How to run:
1. npm install
2. npm install express-session
3. node store-server.js
