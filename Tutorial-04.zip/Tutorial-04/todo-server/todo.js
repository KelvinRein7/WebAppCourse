// //additem
// //additembutton
// //items
// //remove
// //highlight
// //sort

var items = [];
function init() {

  //add button click
  document.getElementById("additembutton").addEventListener("click", addHandler);   
  
  //remove button click
  document.getElementById("removeitem").addEventListener("click", removeHandler);

  //toggle highlight button click
  document.getElementById("highlight").addEventListener("click",toggleHighlight);

  //sort click
  document.getElementById("sort").addEventListener("click",sortHandller);

	setInterval(grabList, 5000);
	grabList();

}

var addHandler = function() {

let flag = true;
let additem = document.getElementById("additem");

//if user input is not empty space
if(additem.value.length >= 1){
  for(let item of items) {
    //if user input the same item that is already on the list
    //will do nothing and take another input
    if (item.name == additem.value) {
      flag = false;
      break;
    }
  }
  if(flag) {
    let item = {name: document.getElementById("additem").value, checked: false, highlighted: false};

    sendItem(item);
    //reset input-text-box
    document.getElementById("additem").value="";
  }
}
  
}    

function displayCheckBox() {

  let firstBox = document.getElementById("items");
  firstBox.innerHTML = "";

  for(let item of items){
      let checkBox = document.createElement("input");
      checkBox.type = "checkbox";
      checkBox.id = item.name;
      checkBox.addEventListener("click", () => {
          item.checked = item.checked ? false : true;
      });
      checkBox.checked = item.checked;

      //first check box will be a row
      let tableRow = document.createElement("tr");

      //starting from second is column to the first row checkbox
      let tableCol1 = document.createElement("td");

      let tableCol2 = document.createElement("td");

      tableCol2.innerHTML = item.name;

      if(item.highlighted==true){tableCol2.className = "container";}

      tableCol1.appendChild(checkBox);
      tableRow.appendChild(tableCol1);
      tableRow.appendChild(tableCol2);
      firstBox.appendChild(tableRow);
  }
}

function toggleHighlight(){
  //if item is checked, it will highlight the checked item
    for(let item of items){
        if(item.checked==true && item.highlighted==false){
            item.highlighted=true;
        }
        //checked and highlighted => will changed back to normal if toggle
        else if(item.checked==true && item.highlighted==true){
            item.highlighted = false;
        }
    }
    displayCheckBox(); 
}

function removeHandler() {
	items.forEach(element => {
		if(element.checked == true){
			removeItem(element);
		}
	})
}

function sortHandller() {
  items.sort((a,b) => {
    if(a.name < b.name){return -1;}
    if(a.name > b.name){return 1;}
    return 0;
    });
displayCheckBox();
}

var items = [];

function grabList(){ //Code from the Trivia Code Example
    let xhttp = new XMLHttpRequest();

	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let responseObject = JSON.parse(xhttp.responseText);
			items = responseObject;
			displayCheckBox();
		}
	};

	xhttp.open("GET", "http://localhost:3000/list", true);
	xhttp.send();
}

function sendItem(item){
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3000/list";

    xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			grabList();
		}
        else if (this.readyState == 4 && this.status != 200){
            alert("Please Retry the Request");
        }
	};

    xhttp.open("POST",url);
    xhttp.setRequestHeader("Content-Type","application/JSON");
    let data = JSON.stringify(item);
    xhttp.send(data);
}

function removeItem(item){
    let xhttp = new XMLHttpRequest();
    let url = "http://localhost:3000/list";

    xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) { //Waiting for the server to return Success
			grabList(); 
		}
        else if (this.readyState == 4 && this.status != 200){
            alert("Please Retry the Request");
        }
	};

    xhttp.open("PUT",url);
    xhttp.setRequestHeader("Content-Type","application/JSON");
    let data = JSON.stringify(item);
    xhttp.send(data);
}