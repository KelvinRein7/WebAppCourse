let questions = 0;  //counts the number of answered questions
let correct = 0;    //counts the number of questions answered correctly
let currentQuestion = null;


function init(){
	document.getElementById("score").innerHTML = `Your score: ${correct}/${questions++}`;
	getNextQuestion();
	document.getElementById("submit").onclick = submitAnswer;	
}

function getNextQuestion(){
	xhttp = new XMLHttpRequest();

    //This is only going to get called when readyState changes
	xhttp.onreadystatechange = function() {
        //If the response is available and was successful
		if(this.readyState==4 && this.status==200){
			//Take the response text (that is in JSON format), parse it into JS object
			let responseObject = JSON.parse(this.responseText);

      //Extract questions from array and update our array
			currentQuestion = responseObject.results[0];
			console.log(currentQuestion); //look at the object; what keys does it have?

            //render this question on our page
			render();
		}
	}
	//request one question from a web server
	xhttp.open("GET", `https://opentdb.com/api.php?amount=1`);
	xhttp.send();
}

function render(){
	// Implement this function
	// it should display the question (and all four of the answers) on the page
	// you can randomly shuffle the options before displaying them 
	//array of all potential anwers

	let ansArr = [];

	//question
	let question = document.getElementById("question");
	question.innerHTML = "";

	let questionView = document.createElement("h3");
	questionView.innerHTML = currentQuestion.question;

	question.appendChild(questionView);

	//answer options
	ansArr.push(currentQuestion.correct_answer);

for(let i = 0; i < currentQuestion.incorrect_answers.length; i++){

	ansArr.push(currentQuestion.incorrect_answers[i]);
}

console.log(ansArr);

//shuffled array of answers
const shuffled = ansArr.sort(() => Math.random() - 0.5);

for(let i = 0; i < ansArr.length; i++){

	if(shuffled[i] == currentQuestion.correct_answer){

		let correctAnswer = document.createElement("input");
		correctAnswer.type = "radio";
		correctAnswer.value = 1;
		correctAnswer.setAttribute("name", "answer");
		correctAnswer.setAttribute("id", "correctAnswer");
	
		let correctLabel = document.createElement("label");
		correctLabel.setAttribute("for","correctAnswer");
		correctLabel.innerHTML = shuffled[i];
	
		question.appendChild(correctAnswer);
		question.appendChild(correctLabel);
		question.appendChild(document.createElement("br"));

		// if(document.getElementById('correctAnswer').checked == false){
		// 	document.getElementById('submit').style.display = 'block';
		// }

		// document.addEventListener('input',(e)=>{

		// 	if(e.target.getAttribute('name')=="answer")
		// 	//console.log(e.target.value)
		// 	document.getElementById('submit').style.display = 'block';
		// 	});
	}

	else {
		let incorrectAnswer = document.createElement("input");
		incorrectAnswer.type="radio";
		incorrectAnswer.value=0;
		incorrectAnswer.setAttribute("name","answer");
		incorrectAnswer.setAttribute("id","incorrectAnswer"+i);

		let incorrectLabel = document.createElement("label");
		incorrectLabel.setAttribute("for","incorrectLabel"+i);
		incorrectLabel.innerHTML= shuffled[i];

		question.appendChild(incorrectAnswer);
		question.appendChild(incorrectLabel);
		question.appendChild(document.createElement("br"));

		console.log(shuffled[i]);	
		}
	}
	document.addEventListener('click',(e)=>{
		if(e.target.getAttribute('name')=="answer")
		document.getElementById('submit').style.display = 'block';
		});
		//reset on refresh or next question
		document.getElementById('submit').style.display = 'none';
}

function submitAnswer(){
	//result = "";
	// Implement this function
	// This function runs when the button is clicked, - it should display user's score
	// You can also request for another question from here to continue the game
	let correctAns = document.getElementById("correctAnswer");

	if(correctAns.checked){
		document.getElementById("score").innerHTML = `Your score: ${correct++}/${questions++}`;
	}
	else
	{
		document.getElementById("score").innerHTML = `Your score: ${correct}/${questions++}`;
	}

	getNextQuestion();

}

//you can add other functions.
