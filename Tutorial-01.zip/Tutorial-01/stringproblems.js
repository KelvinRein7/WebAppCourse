function landscape() {
  let first_line = "";
  let second_line = "";

  function flat(size) {
    for (let count = 0; count < size; count++) {
      first_line += "  ";
      second_line += "__";
    }
  }

  function hill(size) {
    first_line += " ";
    second_line += "/";

    for (let count = 0; count < size; count++) {
      first_line += "_";
      second_line += " ";
    }
    first_line += " ";
    second_line += "\\";
  }

  //START BUILD SCRIPT (do not change this part)
  flat(3);
  hill(4);
  flat(6);
  hill(1);
  flat(1);
  //END BUILD SCRIPT

  return `${first_line}\n${second_line}`;
}

console.log("");
console.log(landscape());
