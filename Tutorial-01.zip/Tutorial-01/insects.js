// function problem1() {
//   var insects = 2;
//   var weeks = 0;

//   while (insects < 10000) {
//     weeks++;
//     insects = 2;

//     var total = insects ** weeks;
//     insects = total;
//   }
//   //console.log(weeks);
//   //console.log(insects);

//   return 0;
// }

function problem1() {
  let insects = 2;
  let weeks = -1;

  do {
    insects = 2;
    weeks++;
    var total = insects ** weeks * 2;
    insects = total;
    console.log(insects);
  } while (insects < 10000);
}

function problem2() {
  let insects = 1;
  let weeks = 1;
  do {
    insects = insects * 2;
    //insects = total;
    //weeks++;
    console.log(insects);

    if (weeks % 4 == 0 && weeks != 0) {
      //insects = insects * 2;
      var kill = insects * 0.4;
      //console.log(kill);
      insects = insects - kill;
    }
    weeks++;
    //console.log(weeks);
    //console.log(insects);
  } while (insects < 10000);
}

//problem1();
problem2();
// problem3();
