// Convert into a drawBox function

function drawBox(numRows, numCols, boxChar) {
  for (let r = 0; r < numRows; r++) {
    let line = "";
    for (let c = 0; c < numCols; c++) {
      if (boxChar == null) {
        line += "X";
      } else {
        line += boxChar;
      }
    }
    console.log(line);
  }
}

drawBox(5, 4, "7");
