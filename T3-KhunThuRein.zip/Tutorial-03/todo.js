//additem
//additembutton
//items
//remove
//highlight
//sort
var items = [];

function init() {

  //add button click
  document.getElementById("additembutton").addEventListener("click", addHandler);   
  
  //remove button click
  document.getElementById("remove").addEventListener("click", removeHandler);

  //toggle highlight button click
  document.getElementById("togglehighlight").addEventListener("click",toggleHighlight);

  //sort click
  document.getElementById("sort").addEventListener("click",sortHandller);
}


var addHandler = function() {

let flag = true;
let additem = document.getElementById("additem");

//if user input is not empty space
if(additem.value.length >= 1){
  for(let item of items) {
    //if user input the same item that is already on the list
    //will do nothing and take another input
    if (item.name == additem.value) {
      flag = false;
      break;
    }
  }
  if(flag) {
    let item = {name: document.getElementById("additem").value, checked: false, highlighted: false};

    items.push(item)
    //reset input-text-box
    document.getElementById("additem").value="";
  }
}
displayCheckBox();
  
}    

function displayCheckBox() {

  let firstBox = document.getElementById("items");
  firstBox.innerHTML = "";

  for(let item of items){
      let checkBox = document.createElement("input");
      checkBox.type = "checkbox";
      checkBox.id = item.name;
      checkBox.addEventListener("click", () => {
          item.checked = item.checked ? false : true;
      });
      checkBox.checked = item.checked;

      //first check box will be a row
      let tableRow = document.createElement("tr");

      //starting from second is column to the first row checkbox
      let tableCol1 = document.createElement("td");

      let tableCol2 = document.createElement("td");

      tableCol2.innerHTML = item.name;

      if(item.highlighted==true){tableCol2.className = "container";}

      tableCol1.appendChild(checkBox);
      tableRow.appendChild(tableCol1);
      tableRow.appendChild(tableCol2);
      firstBox.appendChild(tableRow);
  }
}

function toggleHighlight(){
  //if item is checked, it will highlight the checked item
    for(let item of items){
        if(item.checked==true && item.highlighted==false){
            item.highlighted=true;
        }
        //checked and highlighted => will changed back to normal if toggle
        else if(item.checked==true && item.highlighted==true){
            item.highlighted = false;
        }
    }
    displayCheckBox(); 
}

function removeHandler() {
  items = items.filter((item) => {
    return item.checked==false;
  });   
  displayCheckBox();
}

function sortHandller() {
  items.sort((a,b) => {
    if(a.name < b.name){return -1;}
    if(a.name > b.name){return 1;}
    return 0;
    });
displayCheckBox();
}