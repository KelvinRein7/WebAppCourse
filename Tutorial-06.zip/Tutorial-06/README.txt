Name: Khun Thu Rein
Student ID: 101186023

1. Open folder in VScode or Go to the folder's directory on terminal
2. npm install express
3. npm install pug
4. node recipeserver.js

Then server will start at http://localhost:3000
